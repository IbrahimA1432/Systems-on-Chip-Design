software/main.d: ../software/main.c \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/hwlib.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/alt_hwlibs_ver.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/socal.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/hps.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/alt_gpio.h \
 ../software/hps_0.h ../software/led.h ../software/seg7.h

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/hwlib.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/alt_hwlibs_ver.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/socal.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/hps.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/alt_gpio.h:

../software/hps_0.h:

../software/led.h:

../software/seg7.h:
